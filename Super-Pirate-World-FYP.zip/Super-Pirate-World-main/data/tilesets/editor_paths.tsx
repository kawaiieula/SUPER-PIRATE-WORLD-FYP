<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="editor_paths" tilewidth="64" tileheight="64" tilecount="6" columns="2">
 <image source="../../graphics/tilesets/editor_paths.png" width="128" height="192"/>
</tileset>
